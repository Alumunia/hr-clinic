<?php
	date_default_timezone_set('Asia/Jakarta');
	$con = mysqli_connect("localhost", "hrclinic_1", "hrclinic_1", "hrclinic_1");
?>