<?php 
include('koneksi.php');
session_start();
date_default_timezone_set('Asia/Jakarta');
$profil="actives";

?>



<!DOCTYPE html>
<html lang="en">
   <head>
  <?php require('layout/head.php');?>
	</head>
<?php require('layout/logo.php');?>
 <!--THE BEGINNING ROW 3 KIRI-->
			<!------BEGINNING ROW 6 MIDDLE-------->
			<div class="col-xs-9">
			<div class="container">
			 <img src="assets/images/hrc.png"  class="img-responsive" style="width:400px">
			<br>
		
			
			<div class="col-xs-9">
			 <p style="font-size:16px" align="justify"><strong>Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			<br>	
			<br>	
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			<br>
			<br>
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement Divisi Human Resource (HR) merupakan divisi yang bertanggung jawab atas proses seleksi,rekruitmen,
			penempatan dan orientasi,pelatihan,karier,serta engageement</strong></p>
			</div>
			 
			</div>
				</div>
		<!----SIDEBAR------>
		<?php include('layout/sidebar.php');?>
		<!----THE END OF SIDEBAR---->
          </div><!--/row-->
	<?php include('layout/footer.php');?>
  </body>
 
</html>
